package simulator.model;

import simulator.misc.Vector2D;

public abstract class Body {
	protected String id;
	protected String gid;
	protected Vector2D v;
	protected Vector2D f;
	protected Vector2D p;
	protected int m;
	
	
public Body(String id, String gid, Vector2D v, Vector2D p, int m) {
	this.id = id;
	this.gid = gid;
	this.v = v;
	this.f = new Vector2D();
	this.p = p;
	this.m = m;
}


public String getId() {
	return id;
}


public String getGid() {
	return gid;
}


public Vector2D getVelocidad() {
	return v;
}


public Vector2D getFuerza() {
	return f;
}


public Vector2D getPosicion() {
	return p;
}


public int getMasa() {
	return m;
}
 void addForce(Vector2D f) {
	 this.f = this.f.plus(f);
 }

void resetForce() {
	this.f = new Vector2D();
}
abstract void advance(double dt) {
	
}
public JSONObjetc getState() {
	
}
public String toString() {
	
	return " ";
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
}
