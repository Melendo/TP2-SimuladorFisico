package simulator.model;

public abstract class Body {

}
