package simulator.control;

public class Controller {

}
