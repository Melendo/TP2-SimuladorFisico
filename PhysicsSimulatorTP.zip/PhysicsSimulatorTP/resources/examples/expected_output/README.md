# out.1.json

* was generated using the commnd-line

  -i resources/examples/input/ex1.json -o resources/examples/expected_output/out.1.json -s 1000 -dt 1000 -fl nlug

# out.2.json

* was generated using the commnd-line

  -i resources/examples/input/ex1.json -o resources/examples/expected_output/out.2.json -s 1000 -dt 1000 -fl mtfp

# out.3.json

* was generated using the commnd-line

  -i resources/examples/input/ex2.json -o resources/examples/expected_output/out.3.json -s 1000 -dt 1000 -fl nlug

# out.4.json

* was generated using the commnd-line

  -i resources/examples/input/ex2.json -o resources/examples/expected_output/out.4.json -s 1000 -dt 1000 -fl mtfp

# out.5.json

* was generated using the commnd-line

  -i resources/examples/input/ex3.json -o resources/examples/expected_output/out.5.json -s 1000 -dt 1000 -fl nlug

# out.6.json

* was generated using the commnd-line

  -i resources/examples/input/ex3.json -o resources/examples/expected_output/out.6.json -s 1000 -dt 1000 -fl mtfp

# out.7.json

* was generated using the commnd-line

  -i resources/examples/input/ex4.json -o resources/examples/expected_output/out.7.json -s 1000 -dt 1000 -fl nlug

# out.8.json

* was generated using the commnd-line

  -i resources/examples/input/ex4.json -o resources/examples/expected_output/out.8.json -s 1000 -dt 1000 -fl mtfp

